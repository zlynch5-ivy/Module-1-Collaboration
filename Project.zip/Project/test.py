import unittest
from fractions import Fraction

target = __import__("my_sum")
sum = target.sum

class TestSum(unittest.TestCase):
    def test_list_int(self):

       # To test it can sum the list of integers

       data = [1, 2, 3]
       result = sum(data)
       self.assertEqual(result, 6)

    def test_list_fraction(self):
        # To test fractions and see if they can be summed properly.

        data = [Fraction(1, 4), Fraction(1, 4), Fraction(2, 5)]
        result = sum(data)
        self.assertEqual(result, 1)

if __name__ == "__main__":
    unittest.main()

"""
The integer test will pass, due to 1 + 2 + 3 equalling six, but the fraction
sum test will not pass, as 2 / 5, 1 / 4, and 1 / 4 do not add up to equal 1.
"""